public interface Obliczenia {
    double obliczObwod();
    double obliczPole();
}