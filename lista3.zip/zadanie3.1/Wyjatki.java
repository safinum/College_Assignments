public class Wyjatki {
	public static void niepoprawnyArgument() {
		System.out.println("Niepoprawny argument");
		System.exit(0);
	}

	public static void zlaIloscArgumentow() {
		System.out.println("Niepoprawna liczba argumentow");
		System.exit(0);
	}
}